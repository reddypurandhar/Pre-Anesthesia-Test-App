import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mohit/login_options_page.dart';

class PatientHome extends StatefulWidget {
  final String id;
  const PatientHome({Key? key, required this.id}) : super(key: key);

  @override
  State<PatientHome> createState() => _PatientHomeState();
}

class _PatientHomeState extends State<PatientHome> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        title: Text('Patient Login  '),
        centerTitle: true,// Replace with the doctor's name

      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue[900],
              ),
              child: Column(),
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginOptions()),
                );
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('Patients').doc(widget.id).snapshots(),
          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            }
            if (!snapshot.hasData || !snapshot.data!.exists) {
              return Text(
                'No patient data found',
                style: TextStyle(fontSize: 16, color: Colors.white),
              );
            }
            var patient = snapshot.data!;
            var status = patient['status'];
            var rejectionReason = patient['rejectionReason'] ?? '';

            return Container(
              width: 270,
              height: 150,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  // Profile picture avatar
                  backgroundImage: NetworkImage(patient['photoUrl']),

                ),
                title: Text(patient['name']),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Patient ID: ${patient.id}'),
                    SizedBox(height: 5),
                    if (status == 'Rejected')
                      Text(
                        'Status: Rejected\nRejection Reason: $rejectionReason',
                        style: TextStyle(color: Colors.red),
                      ),
                    if (status == 'Approved') Text('Status: Approved'),
                    if (status == 'pending') Text('Status: Pending'),
                  ],
                ),
                onTap: () {
                  // Handle tap event if needed
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
