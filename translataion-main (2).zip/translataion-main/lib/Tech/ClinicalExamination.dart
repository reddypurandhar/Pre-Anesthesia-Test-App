import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CEScreen extends StatefulWidget {
  final String id;
  const CEScreen({Key? key, required this.id,}) : super(key: key);
  @override
  _CEScreenState createState() => _CEScreenState();
}

class _CEScreenState extends State<CEScreen> {
  TextEditingController _msController = TextEditingController();
  TextEditingController _rrController = TextEditingController();
  TextEditingController _peController = TextEditingController();
  TextEditingController _jController = TextEditingController();
  TextEditingController _scController = TextEditingController();
  TextEditingController _pvaController = TextEditingController();
  TextEditingController _bsController = TextEditingController();
  TextEditingController _hsController = TextEditingController();



  void _saveData() {
    List<String> laboratoryRecord = [
    _msController.text,
     _rrController .text,
     _peController.text,
     _jController .text,
     _scController.text,
     _pvaController.text,
     _bsController .text,
     _hsController.text,
    ];

    FirebaseFirestore.instance.collection('PatientsClinical').doc(widget.id).set({
      'Clinical Record': laboratoryRecord,
    }).then((value) {
      // Data saved successfully
      print('Data saved successfully');
      Navigator.pop(context);
      // You can add any additional actions here after saving data
    }).catchError((error) {
      // An error occurred while saving data
      print('Error saving data: $error');
    });
  }
  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Clinical Examination',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 200), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('Mental Status AVPU', _msController),
                      _buildTextField('RR(/min)', _rrController),
                      _buildTextField('Peripheral Edema', _peController),
                      _buildTextField('Jaundice', _jController),
                      _buildTextField('Spinal Curvature', _scController),
                      _buildTextField(
                          'Peripheral venous access', _pvaController),
                      _buildTextField('Breath Sounds', _bsController),
                      _buildTextField('Heart Sounds', _hsController),
                      // Add other text fields...
                      SizedBox(height: 30),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _saveData,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            padding: EdgeInsets.symmetric(vertical: 15.0),
                          ),
                          child: Text(
                            'Save',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 220.0,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}