import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ECGScreen extends StatefulWidget {
  final String id;
  const ECGScreen({Key? key, required this.id,}) : super(key: key);
  @override
  _ECGScreenState createState() => _ECGScreenState();
}

class _ECGScreenState extends State<ECGScreen> {
  TextEditingController _ecgController = TextEditingController();
  TextEditingController _cxpvController = TextEditingController();
  TextEditingController _recController = TextEditingController();
  TextEditingController _lvhController = TextEditingController();
  TextEditingController _ddController = TextEditingController();
  TextEditingController _valvesController = TextEditingController();
  TextEditingController _papController = TextEditingController();
  TextEditingController _rwmaController = TextEditingController();



  void _saveData() {
    List<String> laboratoryRecord = [
    _ecgController.text,
     _cxpvController.text,
     _recController.text,
     _lvhController .text,
     _ddController .text,
     _valvesController .text,
     _papController .text,
     _rwmaController .text,
    ];

    FirebaseFirestore.instance.collection('PatientsECG').doc(widget.id).set({
      'ECG Record': laboratoryRecord,
    }).then((value) {
      // Data saved successfully
      print('Data saved successfully');
      Navigator.pop(context);
      // You can add any additional actions here after saving data
    }).catchError((error) {
      // An error occurred while saving data
      print('Error saving data: $error');
    });
  }
  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    return  Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'ECG/Chest X-Ray PA view',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 150), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('ECG', _ecgController),
                      _buildTextField('Chest X-Ray PA view', _cxpvController),
                      _buildTextField(
                          'Resting Echo Cardiography(%)', _recController),
                      _buildTextField('LVH', _lvhController),
                      _buildTextField('DD', _ddController),
                      _buildTextField('valves', _valvesController),
                      _buildTextField('PA Pressure', _papController),
                      _buildTextField('RWMA', _rwmaController),
                      // Add other text fields...
                      SizedBox(height: 30),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed:_saveData,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            padding: EdgeInsets.symmetric(vertical: 15.0),
                          ),
                          child: Text(
                            'Save',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 220.0,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}