import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

import 'package:mohit/Doctor/HomeScreen.dart';
import 'package:mohit/Tech/TechHome.dart';

class Tech_Profile extends StatefulWidget {
  final String id;
  const Tech_Profile({Key? key, required this.id}) : super(key: key);

  @override
  _Tech_ProfileState createState() => _Tech_ProfileState();
}

class _Tech_ProfileState extends State<Tech_Profile> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController doctorIdController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController MobileController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  File? _image;
  bool _isEditing = false;
  String? _profileImageUrl;
  String? name;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    DocumentSnapshot userData = await _firestore.collection('tech').doc(widget.id).get();
    if (userData.exists) {
      Map<String, dynamic>? data = userData.data() as Map<String, dynamic>?;

      if (data != null) {
        setState(() {
          doctorIdController.text = data['tech_id'] ?? '';
          nameController.text = data['name'] ?? '';
          genderController.text = data['gender'] ?? '';
          MobileController.text = data['mobile_number'] ?? '';

          name = data['name'] ?? ''; // Setting the name value for displaying
        });
      }
    }
  }








  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Scaffold(
        backgroundColor: Colors.blue[900],
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TechHome(id: widget.id),
                            ),
                          );
                        },
                      ),
                      Spacer(),

                    ],
                  ),
                ),

                SizedBox(height: 40,),
                Container(
                  alignment: Alignment.center,
                  child: Text(
                    name!,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                ),
                SizedBox(height: 80,),
                Container(
                  width: double.infinity,
                  alignment: AlignmentDirectional(0, 1),
                  child: Container(
                    width: 100,
                    height: 500,
                    constraints: BoxConstraints(
                      minWidth: double.infinity,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(40),
                        topRight: Radius.circular(40),
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: 25,),
                          TextFormField(
                            controller: doctorIdController,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Doctor ID',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              filled: true,
                              fillColor: Colors.grey[200],
                              contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                          ),
                          SizedBox(height: 25,),
                          TextFormField(
                            controller: nameController,
                            enabled: _isEditing,
                            decoration: InputDecoration(
                              labelText: 'Name',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              filled: true,
                              fillColor: Colors.grey[200],
                              contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                          ),
                          SizedBox(height: 25,),
                          TextFormField(
                            controller: MobileController,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Mobile Number',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              filled: true,
                              fillColor: Colors.grey[200],
                              contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                          ),
                          SizedBox(height: 25,),
                          TextFormField(
                            controller: genderController,
                            enabled: _isEditing,
                            decoration: InputDecoration(
                              labelText: 'Gender',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              filled: true,
                              fillColor: Colors.grey[200],
                              contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            ),
                          ),
                          SizedBox(height: 25,),

                          SizedBox(height: 20),
                          _isEditing
                              ? doctorIdController.text.isEmpty && nameController.text.isEmpty
                              ? SizedBox.shrink()
                              : SizedBox(
                            height: 40,
                            child: ElevatedButton(
                              onPressed: (){},
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: Text(
                                  'Save',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue[900],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(25),
                                ),
                              ),
                            ),
                          )
                              :Container(),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
