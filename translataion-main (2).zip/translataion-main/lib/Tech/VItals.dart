import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
class VitalsScreen extends StatefulWidget {
  final String id;
  const VitalsScreen({Key? key, required this.id,}) : super(key: key);
  @override
  _VitalsScreenState createState() => _VitalsScreenState();
}

class _VitalsScreenState extends State<VitalsScreen> {
  final TextEditingController _hrController = TextEditingController();
  final TextEditingController _bpController = TextEditingController();
  final TextEditingController _spo2Controller = TextEditingController();
  final TextEditingController _rrController = TextEditingController();
  final TextEditingController _serologyController = TextEditingController();
  final TextEditingController _covidController = TextEditingController();

  @override
  void _saveData() {
    List<String> laboratoryRecord = [
    _hrController.text,
      _bpController.text,
      _spo2Controller .text,
      _rrController .text,
      _serologyController.text,
      _covidController .text,
    ];

    FirebaseFirestore.instance.collection('PatientsVitals').doc(widget.id).set({
      'vitals Record': laboratoryRecord,
    }).then((value) {
      // Data saved successfully
      print('Data saved successfully');
      Navigator.pop(context);
      // You can add any additional actions here after saving data
    }).catchError((error) {
      // An error occurred while saving data
      print('Error saving data: $error');
    });
  }
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        title: Text('Vitals'),
        centerTitle: true,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          SizedBox(height: 40),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    _buildTextField('Heart Rate', _hrController),
                    _buildTextField('Blood Pressure(BP)', _bpController),
                    _buildTextField('Spo2', _spo2Controller),
                    _buildTextField('Respiratory Rate', _rrController),
                    _buildTextField('Serology', _serologyController),
                    _buildTextField('COVID', _covidController),
                    // Add other text fields...
                    SizedBox(height: 30),
                    SizedBox(
                      width: double
                          .infinity, // Ensure button stretches to full width
                      child: ElevatedButton(
                        onPressed: _saveData,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[900],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 15.0),
                        ),
                        child: Text(
                          'Save',
                          style: TextStyle(
                            fontSize:
                            18, // Use Sizer for responsive font sizing
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          // Add some space below the container
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 220.0,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 18, // Use Sizer for responsive font sizing
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}