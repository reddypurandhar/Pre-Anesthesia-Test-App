import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class LDScreen extends StatefulWidget {
  final String id;
  const LDScreen({Key? key, required this.id,}) : super(key: key);
  @override
  _LDScreenState createState() => _LDScreenState();
}

class _LDScreenState extends State<LDScreen> {
  TextEditingController _hbController = TextEditingController();
  TextEditingController _tlcController = TextEditingController();
  TextEditingController _dlcController = TextEditingController();
  TextEditingController _plateletController = TextEditingController();
  TextEditingController _bgController = TextEditingController();
  TextEditingController _ptController = TextEditingController();
  TextEditingController _inrController = TextEditingController();
  TextEditingController _apttController = TextEditingController();
  TextEditingController _fbsController = TextEditingController();
  TextEditingController _2hppbsController = TextEditingController();
  TextEditingController _rbsController = TextEditingController();
  TextEditingController _hba1cController = TextEditingController();
  TextEditingController _serumnaController = TextEditingController();
  TextEditingController _serumkController = TextEditingController();
  TextEditingController _serumureaController = TextEditingController();
  TextEditingController _serumcreatnineController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;



    void _saveData() {
      List<String> laboratoryRecord = [
        _hbController.text,
        _tlcController.text,
        _dlcController.text,
        _plateletController.text,
        _bgController.text,
        _ptController.text,
        _inrController.text,
        _apttController.text,
        _fbsController.text,
        _2hppbsController.text,
        _rbsController.text,
        _hba1cController.text,
        _serumnaController.text,
        _serumkController.text,
        _serumureaController.text,
        _serumcreatnineController.text,
      ];

      FirebaseFirestore.instance.collection('PatientsLab').doc(widget.id).set({
        'Laboratory Record': laboratoryRecord,
      }).then((value) {
        // Data saved successfully
        print('Data saved successfully');
        Navigator.pop(context);
        // You can add any additional actions here after saving data
      }).catchError((error) {
        // An error occurred while saving data
        print('Error saving data: $error');
      });
    }


    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Laboratory Data',
                  style: TextStyle(
                    fontSize: 20, // Use Sizer for responsive font sizing
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 40),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextField('Hb(g/dL)', _hbController),
                    _buildTextField('TLC', _tlcController),
                    _buildTextField('DLC(%)', _dlcController),
                    _buildTextField('Platelet(cu/mm)', _plateletController),
                    _buildTextField('Blood Group', _bgController),
                    _buildTextField('PT(s)', _ptController),
                    _buildTextField('INR', _inrController),
                    _buildTextField('aPTT(s)', _apttController),
                    _buildTextField('FBS(mg/dL)', _fbsController),
                    _buildTextField('2h PPBS(mg/dL)', _2hppbsController),
                    _buildTextField('RBS(mg/dL)', _rbsController),
                    _buildTextField('HbA1c(g/dL)', _hba1cController),
                    _buildTextField('Serum Na(mmol/L)', _serumnaController),
                    _buildTextField('Serum K(mmol/L)', _serumkController),
                    _buildTextField('Serum Urea', _serumureaController),
                    _buildTextField(
                        'Serum Creatnine', _serumcreatnineController),
                    // Add other text fields...
                    SizedBox(height: 30),
                    SizedBox(
                      width: double
                          .infinity, // Ensure button stretches to full width
                      child: ElevatedButton(
                        onPressed: _saveData,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[900],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 15.0),
                        ),
                        child: Text(
                          'Save',
                          style: TextStyle(
                            fontSize:
                            18, // Use Sizer for responsive font sizing
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 220.0,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 18, // Use Sizer for responsive font sizing
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}