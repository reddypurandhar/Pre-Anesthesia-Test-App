import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AAScreen extends StatefulWidget {
  final String id;
  const AAScreen({Key? key, required this.id,}) : super(key: key);
  @override
  _AAScreenState createState() => _AAScreenState();
}

class _AAScreenState extends State<AAScreen> {
  TextEditingController _iigController = TextEditingController();
  TextEditingController _mgController = TextEditingController();
  TextEditingController _tmdController = TextEditingController();
  TextEditingController _nmController = TextEditingController();
  TextEditingController _admvController = TextEditingController();
  TextEditingController _adtiController = TextEditingController();


  void _saveData() {
    List<String> laboratoryRecord = [
    _iigController.text,
     _mgController.text,
     _tmdController .text,
     _nmController .text,
     _admvController.text,
     _adtiController.text,
    ];

    FirebaseFirestore.instance.collection('PatientsAirway').doc(widget.id).set({
      'Airway Record': laboratoryRecord,
    }).then((value) {
      // Data saved successfully
      print('Data saved successfully');
      Navigator.pop(context);
      // You can add any additional actions here after saving data
    }).catchError((error) {
      // An error occurred while saving data
      print('Error saving data: $error');
    });
  }


  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(

      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Airway Assessment',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 200), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('Inter-incisor gap ', _iigController),
                      _buildTextField('Mallampati grade', _mgController),
                      _buildTextField('Thyro-mental distance', _tmdController),
                      _buildTextField('Neck Movement', _nmController),
                      _buildTextField('Anticipated difficult mack ventilation',
                          _admvController),
                      _buildTextField(
                          'Anticipated difficult tracheal intuibation :',
                          _adtiController),
                      // Add other text fields...
                      SizedBox(height: 30),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _saveData,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            padding: EdgeInsets.symmetric(vertical: 15.0),
                          ),
                          child: Text(
                            'Save',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 220.0,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 10.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}