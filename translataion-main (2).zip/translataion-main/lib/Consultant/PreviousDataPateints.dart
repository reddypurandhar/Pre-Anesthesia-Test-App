import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:mohit/Consultant/TranslationView/CancerV.dart';
import 'package:mohit/Consultant/TranslationView/Womens.dart';
import 'package:mohit/Consultant/TranslationView/eye.dart';
import 'package:mohit/Consultant/TranslationView/respiratoryV.dart';

import '../Doctor/Translations/Bladder.dart';
import '../Doctor/Translations/Cardiovascular.dart';
import '../Doctor/Translations/Diabetes.dart';
import '../Doctor/Translations/Neurological.dart';
import '../Doctor/Translations/anesthesia.dart';
import '../Doctor/Translations/blood.dart';
import '../Doctor/Translations/cancer.dart';
import '../Doctor/Translations/eye-ear.dart';
import '../Doctor/Translations/forwomen.dart';
import '../Doctor/Translations/gastro.dart';
import '../Doctor/Translations/others.dart';
import '../Doctor/Translations/respiratory.dart';
import 'TranslationView/AnesthisiaV.dart';
import 'TranslationView/BladderV.dart';
import 'TranslationView/BloodV.dart';
import 'TranslationView/CardiovascularView.dart';
import 'TranslationView/DiabetesV.dart';
import 'TranslationView/OthersV.dart';
import 'TranslationView/gastrov.dart';
import 'TranslationView/neurov.dart';


class PatientPreviousData extends StatefulWidget {
  final String Patientid;
  final String name;
  final String photourl;

  const PatientPreviousData({
    Key? key,
    required this.Patientid,
    required this.name,
    required this.photourl,
  }) : super(key: key);

  @override
  State<PatientPreviousData> createState() => _PatientPreviousDataState();
}

class _PatientPreviousDataState extends State<PatientPreviousData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('History of Patients',style: TextStyle(color: Colors.black),),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.blue[900],
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  ClipPath(
                    clipper: WaveClipperOne(),
                    child: Container(
                      height: 180,
                      color: Colors.white,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 50,
                              backgroundImage: NetworkImage(widget.photourl), // Replace with your profile image
                            ),
                            SizedBox(height: 10),
                            Text(
                              widget.name,
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 45),
                  Container(
                    width: 250,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => CardiovascularV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Cardiovascular Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Respiratory Disease
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  respiratoryV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Respiratory Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Neurological Disorder
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  NeuroV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Neurological Disorder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Diabetes
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  DiabetesV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Diabetes',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Kidney/Bladder
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  BladderV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Kidney/Bladder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Gastro-Interstinal Disease
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  gastroV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Gastro-Interstinal Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Blood Disorder
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) =>  BloodV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Blood Disorder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Eye/Ear
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  EyeV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Eye/Ear',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Cancer/Chemotherapy/Radiation
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  CancerV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Cancer/Chemotherapy/Radiation',style: TextStyle(fontSize: 16),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for For Women
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  WomensV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('For Women',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Previous Anesthesia
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  AnesthesiaV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Previous Anesthesia',style: TextStyle(fontSize: 19),),
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Other
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  OthersV(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Other',style: TextStyle(fontSize: 19),),
                    ),
                  ),
                  SizedBox(height: 50),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
