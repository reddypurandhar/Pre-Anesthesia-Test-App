import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'Consultant_Home.dart';


class consultant extends StatefulWidget {
  const consultant({Key? key}) : super(key: key);

  @override
  State<consultant> createState() => _consultantState();
}

class _consultantState extends State<consultant> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
      ),
      backgroundColor: Colors.blue[900],
      body: Center(
        child: Container(
          width: 350,
          height: 450,
          color: Colors.white,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/consultant.png', // Replace with your image asset
                width: 150,
                height: 150,
              ),
              SizedBox(height: 20),
              Text(
                'Login',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    hintText: 'ID',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(height: 20),
              _isLoading
                  ? CircularProgressIndicator() // Show loading indicator when signing in
                  : Container(
                width: 250,
                child: ElevatedButton(
                  onPressed: _signIn,
                  child: Text('Login'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  void _signIn() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Retrieve the document from the Firestore collection
      DocumentSnapshot docSnapshot = await FirebaseFirestore.instance
          .collection('Consultant')
          .doc(_emailController.text.trim())
          .get();

      // Check if the document exists and the password matches
      if (docSnapshot.exists) {
        Map<String, dynamic>? data = docSnapshot.data() as Map<String, dynamic>?;

        if (data != null && data['password'] == _passwordController.text.trim()) {
          // Navigate to TechHome page
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => ConsultantHome(id: _emailController.text,)),
          );
          return ;
        }
      }

      // Show error message if ID or password is incorrect
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Invalid ID or password'),
        ),
      );
    } catch (e) {
      // Show error message if there's any error fetching data from Firestore
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
