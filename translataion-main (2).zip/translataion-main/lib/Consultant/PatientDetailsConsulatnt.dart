import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mohit/Doctor/Patient%20details.dart';
import 'package:sizer/sizer.dart';

import 'Lab Reports/profilelaboratory.dart';
import 'PreviousDataPateints.dart';

class ConsultantPatientDetails extends StatefulWidget {
  final String id;
  const ConsultantPatientDetails({Key? key, required this.id}) : super(key: key);

  @override
  _ConsultantPatientDetailsState createState() => _ConsultantPatientDetailsState();
}

class _ConsultantPatientDetailsState extends State<ConsultantPatientDetails> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _ageController = TextEditingController();
  TextEditingController _heightController = TextEditingController();
  TextEditingController _weightController = TextEditingController();
  TextEditingController _procedureController = TextEditingController();
  TextEditingController _dateofsurgeryController = TextEditingController();
  late final String name;
  late final String photourl;
  late final String id;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchUserData();

  }
  void _rejectPatient(String reason) {
    FirebaseFirestore.instance.collection('Patients').doc(widget.id).update({
      'status': 'Rejected',
      'rejectionReason': reason,
    }).then((value) {
      // Data saved successfully
      print('Rejected');
    }).catchError((error) {
      // An error occurred while saving data
      print('Error saving data: $error');
    });
  }
  void _showRejectionReasonDialog() {
    TextEditingController reasonController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Reason for Rejection'),
          content: TextField(
            controller: reasonController,
            decoration: InputDecoration(hintText: 'Enter reason'),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                String reason = reasonController.text;
                if (reason.isNotEmpty) {
                  _rejectPatient(reason);
                  Navigator.of(context).pop();
                } else {
                  // Show a snackbar indicating that reason is required
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Please enter a reason for rejection'),
                    ),
                  );
                }
              },
              child: Text('Submit'),
            ),
          ],
        );
      },
    );
  }
  Future<void> _fetchUserData() async {
    DocumentSnapshot userData = await _firestore.collection('Patients').doc(widget.id).get();
    if (userData.exists) {
      Map<String, dynamic>? data = userData.data() as Map<String, dynamic>?;

      if (data != null) {
        setState(() {
          _usernameController.text = data['name'] ?? '';
          _ageController.text = data['age'] ?? '';
          _heightController.text = data['height'] ?? '';
          _weightController.text = data['weight'] ?? '';
          _procedureController.text = data['phone'] ?? '';
          _dateofsurgeryController.text = data['dateOfSurgery'] ?? '';
          photourl=data['photoUrl']??'';
          id=widget.id;

          name = data['name'] ?? ''; // Setting the name value for displaying
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'Patient Details',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40),
                  topRight: Radius.circular(40),
                ),
              ),
              padding: EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildTextField('Name', _usernameController),
                  _buildTextField('Age', _ageController),
                  _buildTextField('Height', _heightController),
                  _buildTextField('Weight', _weightController),
                  _buildTextField('Procedure', _procedureController),
                  _buildTextField('Date of Surgery', _dateofsurgeryController),
                  SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => PatientPreviousData(Patientid: widget.id, name: name, photourl: photourl,)),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blue[900],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 50),
                    ),
                    child: Text(
                      'Previous History of Patient',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w300,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LaboratoryDataV(patientId: widget.id, name: name, age:_ageController.text)),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blue[900],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 100),
                    ),
                    child: Text(
                      'Lab Reports',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w300,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          FirebaseFirestore.instance.collection('Patients').doc(widget.id).update({
                            'status': 'Approved',
                          }).then((value) {
                            // Data saved successfully
                            print('Approved');

                            // You can add any additional actions here after saving data
                          }).catchError((error) {
                            // An error occurred while saving data
                            print('Error saving data: $error');
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.blue[900],
                          padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                          minimumSize: Size(150, 0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0),
                          ),

                        ),
                        child: Text(
                          'Approve',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () {
                          _showRejectionReasonDialog();
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.blue[900],
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                          minimumSize: Size(150, 0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0),
                          ),
                        ),
                        child: Text(
                          'Reject',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w300,
                color: Colors.black,
              ),
            ),
          ),
          Text(
            ":",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: TextField(

              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}