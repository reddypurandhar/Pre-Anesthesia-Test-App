import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AAScreenV extends StatefulWidget {
  final String id;
  const AAScreenV({Key? key, required this.id,}) : super(key: key);
  @override
  _AAScreenVState createState() => _AAScreenVState();
}

class _AAScreenVState extends State<AAScreenV> {
  TextEditingController _iigController = TextEditingController();
  TextEditingController _mgController = TextEditingController();
  TextEditingController _tmdController = TextEditingController();
  TextEditingController _nmController = TextEditingController();
  TextEditingController _admvController = TextEditingController();
  TextEditingController _adtiController = TextEditingController();


  void initState() {
    super.initState();
    // Fetch existing airway assessment data for the patient from Firestore
    fetchAirwayData();
  }

  void fetchAirwayData() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('PatientsAirway').doc(widget.id).get();
      // Get the airway assessment data array
      List<dynamic>? data = patientDoc['Airway Record'];
      if (data != null) {
        setState(() {
          _iigController.text = data[0];
          _mgController.text = data[1];
          _tmdController.text = data[2];
          _nmController.text = data[3];
          _admvController.text = data[4];
          _adtiController.text = data[5];
        });
      }
    } catch (e) {
      print('Error fetching airway assessment data: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Airway Assessment',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 200), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('Inter-incisor gap ', _iigController),
                      _buildTextField('Mallampati grade', _mgController),
                      _buildTextField('Thyro-mental distance', _tmdController),
                      _buildTextField('Neck Movement', _nmController),
                      _buildTextField('Anticipated difficult mack ventilation',
                          _admvController),
                      _buildTextField(
                          'Anticipated difficult tracheal intuibation :',
                          _adtiController),
                      // Add other text fields...
                      SizedBox(height: 30),

                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 230.0,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(

                label,
                style: TextStyle(
                  fontSize: 20, // Use Sizer for responsive font sizing
                  fontWeight: FontWeight.w300,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(

                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}