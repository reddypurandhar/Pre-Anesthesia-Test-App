import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CEScreenV extends StatefulWidget {
  final String id;
  const CEScreenV({Key? key, required this.id}) : super(key: key);
  @override
  _CEScreenVState createState() => _CEScreenVState();
}

class _CEScreenVState extends State<CEScreenV> {
  TextEditingController _msController = TextEditingController();
  TextEditingController _rrController = TextEditingController();
  TextEditingController _peController = TextEditingController();
  TextEditingController _jController = TextEditingController();
  TextEditingController _scController = TextEditingController();
  TextEditingController _pvaController = TextEditingController();
  TextEditingController _bsController = TextEditingController();
  TextEditingController _hsController = TextEditingController();

  void initState() {
    super.initState();
    // Fetch existing clinical examination data for the patient from Firestore
    fetchClinicalData();
  }

  void fetchClinicalData() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('PatientsClinical').doc(widget.id).get();
      // Get the clinical examination data array
      List<dynamic>? data = patientDoc['Clinical Record'];
      if (data != null) {
        setState(() {
          _msController.text = data[0];
          _rrController.text = data[1];
          _peController.text = data[2];
          _jController.text = data[3];
          _scController.text = data[4];
          _pvaController.text = data[5];
          _bsController.text = data[6];
          _hsController.text = data[7];
        });
      }
    } catch (e) {
      print('Error fetching clinical examination data: $e');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Clinical Examination',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 200), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('Mental Status AVPU', _msController),
                      _buildTextField('RR(/min)', _rrController),
                      _buildTextField('Peripheral Edema', _peController),
                      _buildTextField('Jaundice', _jController),
                      _buildTextField('Spinal Curvature', _scController),
                      _buildTextField('Peripheral venous access', _pvaController),
                      _buildTextField('Breath Sounds', _bsController),
                      _buildTextField('Heart Sounds', _hsController),
                      // Add other text fields...
                      SizedBox(height: 30),

                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 230.0,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(

                label,
                style: TextStyle(
                  fontSize: 20, // Use Sizer for responsive font sizing
                  fontWeight: FontWeight.w300,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(

                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
