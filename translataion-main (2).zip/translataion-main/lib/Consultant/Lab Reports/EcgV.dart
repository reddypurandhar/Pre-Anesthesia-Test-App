import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ECGScreenV extends StatefulWidget {
  final String id;
  const ECGScreenV({Key? key, required this.id,}) : super(key: key);
  @override
  _ECGScreenVState createState() => _ECGScreenVState();
}

class _ECGScreenVState extends State<ECGScreenV> {
  TextEditingController _ecgController = TextEditingController();
  TextEditingController _cxpvController = TextEditingController();
  TextEditingController _recController = TextEditingController();
  TextEditingController _lvhController = TextEditingController();
  TextEditingController _ddController = TextEditingController();
  TextEditingController _valvesController = TextEditingController();
  TextEditingController _papController = TextEditingController();
  TextEditingController _rwmaController = TextEditingController();



  @override
  void initState() {
    super.initState();
    // Fetch existing ECG data for the patient from Firestore
    fetchECGData();
  }

  void fetchECGData() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('PatientsECG').doc(widget.id).get();
      // Get the ECG data array
      List<dynamic>? data = patientDoc['ECG Record'];
      if (data != null) {
        setState(() {
          _ecgController.text = data[0];
          _cxpvController.text = data[1];
          _recController.text = data[2];
          _lvhController.text = data[3];
          _ddController.text = data[4];
          _valvesController.text = data[5];
          _papController.text = data[6];
          _rwmaController.text = data[7];
        });
      }
    } catch (e) {
      print('Error fetching ECG data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    return  Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'ECG/Chest X-Ray PA view',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 150), // Add space below the "Vitals" text
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildTextField('ECG', _ecgController),
                      _buildTextField('Chest X-Ray PA view', _cxpvController),
                      _buildTextField(
                          'Resting Echo Cardiography(%)', _recController),
                      _buildTextField('LVH', _lvhController),
                      _buildTextField('DD', _ddController),
                      _buildTextField('valves', _valvesController),
                      _buildTextField('PA Pressure', _papController),
                      _buildTextField('RWMA', _rwmaController),
                      // Add other text fields...
                      SizedBox(height: 30),

                      SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 230.0,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(

                label,
                style: TextStyle(
                  fontSize: 20, // Use Sizer for responsive font sizing
                  fontWeight: FontWeight.w300,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(

                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}