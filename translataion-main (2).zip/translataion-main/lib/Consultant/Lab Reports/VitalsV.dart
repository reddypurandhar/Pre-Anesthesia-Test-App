import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
class VitalsScreenV extends StatefulWidget {
  final String id;
  const VitalsScreenV({Key? key, required this.id,}) : super(key: key);
  @override
  _VitalsScreenVState createState() => _VitalsScreenVState();
}

class _VitalsScreenVState extends State<VitalsScreenV> {
  final TextEditingController _hrController = TextEditingController();
  final TextEditingController _bpController = TextEditingController();
  final TextEditingController _spo2Controller = TextEditingController();
  final TextEditingController _rrController = TextEditingController();
  final TextEditingController _serologyController = TextEditingController();
  final TextEditingController _covidController = TextEditingController();

  @override
  @override
  void initState() {
    super.initState();
    // Fetch existing vitals data for the patient from Firestore
    fetchVitalsData();
  }

  void fetchVitalsData() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('PatientsVitals').doc(widget.id).get();
      // Get the vitals data array
      List<dynamic>? data = patientDoc['vitals Record'];
      if (data != null) {
        setState(() {
          _hrController.text = data[0];
          _bpController.text = data[1];
          _spo2Controller.text = data[2];
          _rrController.text = data[3];
          _serologyController.text = data[4];
          _covidController.text = data[5];
        });
      }
    } catch (e) {
      print('Error fetching vitals data: $e');
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        title: Text('Vitals'),
        centerTitle: true,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          SizedBox(height: 40),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    _buildTextField('Heart Rate          ', _hrController),
                    _buildTextField('Blood Pressure(BP)', _bpController),
                    _buildTextField('Spo2', _spo2Controller),
                    _buildTextField('Respiratory Rate', _rrController),
                    _buildTextField('Serology', _serologyController),
                    _buildTextField('COVID', _covidController),
                    // Add other text fields...
                    SizedBox(height: 30),

                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          // Add some space below the container
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 230.0,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(

                label,
                style: TextStyle(
                  fontSize: 20, // Use Sizer for responsive font sizing
                  fontWeight: FontWeight.w300,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(

                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}