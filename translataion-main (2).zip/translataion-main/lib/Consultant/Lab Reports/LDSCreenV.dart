import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class LDSCreenV extends StatefulWidget {
  final String id;
  const LDSCreenV({Key? key, required this.id,}) : super(key: key);
  @override
  _LDSCreenVState createState() => _LDSCreenVState();
}

class _LDSCreenVState extends State<LDSCreenV> {
  TextEditingController _hbController = TextEditingController();
  TextEditingController _tlcController = TextEditingController();
  TextEditingController _dlcController = TextEditingController();
  TextEditingController _plateletController = TextEditingController();
  TextEditingController _bgController = TextEditingController();
  TextEditingController _ptController = TextEditingController();
  TextEditingController _inrController = TextEditingController();
  TextEditingController _apttController = TextEditingController();
  TextEditingController _fbsController = TextEditingController();
  TextEditingController _2hppbsController = TextEditingController();
  TextEditingController _rbsController = TextEditingController();
  TextEditingController _hba1cController = TextEditingController();
  TextEditingController _serumnaController = TextEditingController();
  TextEditingController _serumkController = TextEditingController();
  TextEditingController _serumureaController = TextEditingController();
  TextEditingController _serumcreatnineController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Fetch existing data for the patient from Firestore
    fetchLabData();
  }

  void fetchLabData() async {
    try {
      DocumentSnapshot labDoc =
      await FirebaseFirestore.instance.collection('PatientsLab').doc(widget.id).get();

      List<dynamic>? labRecord = labDoc['Laboratory Record'];
      if (labRecord != null) {
        setState(() {
          _hbController.text = labRecord[0];
          _tlcController.text = labRecord[1];
          _dlcController.text = labRecord[2];
          _plateletController.text = labRecord[3];
          _bgController.text = labRecord[4];
          _ptController.text = labRecord[5];
          _inrController.text = labRecord[6];
          _apttController.text = labRecord[7];
          _fbsController.text = labRecord[8];
          _2hppbsController.text = labRecord[9];
          _rbsController.text = labRecord[10];
          _hba1cController.text = labRecord[11];
          _serumnaController.text = labRecord[12];
          _serumkController.text = labRecord[13];
          _serumureaController.text = labRecord[14];
          _serumcreatnineController.text = labRecord[15];
        });
      }
    } catch (e) {
      print('Error fetching laboratory data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Center(
                child: Text(
                  'Laboratory Data',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 40),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40.0),
                  topRight: Radius.circular(40.0),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextField('Hb(g/dL)', _hbController),
                    _buildTextField('TLC', _tlcController),
                    _buildTextField('DLC(%)', _dlcController),
                    _buildTextField('Platelet(cu/mm)', _plateletController),
                    _buildTextField('Blood Group', _bgController),
                    _buildTextField('PT(s)', _ptController),
                    _buildTextField('INR', _inrController),
                    _buildTextField('aPTT(s)', _apttController),
                    _buildTextField('FBS(mg/dL)', _fbsController),
                    _buildTextField('2h PPBS(mg/dL)', _2hppbsController),
                    _buildTextField('RBS(mg/dL)', _rbsController),
                    _buildTextField('HbA1c(g/dL)', _hba1cController),
                    _buildTextField('Serum Na(mmol/L)', _serumnaController),
                    _buildTextField('Serum K(mmol/L)', _serumkController),
                    _buildTextField('Serum Urea', _serumureaController),
                    _buildTextField(
                        'Serum Creatnine', _serumcreatnineController),
                    SizedBox(height: 30),

                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          SizedBox(
            width: 210.0,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(

                label,
                style: TextStyle(
                  fontSize: 20, // Use Sizer for responsive font sizing
                  fontWeight: FontWeight.w300,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          SizedBox(width: 12.0),
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              readOnly: true,
              controller: controller,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(

                isDense: true, // Reduce the height of the text field
                contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.black, width: 2.0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
