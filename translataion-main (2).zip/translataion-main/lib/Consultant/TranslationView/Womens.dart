import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class WomensV extends StatefulWidget {
  final String patientId;
  const WomensV({Key? key, required this.patientId}) : super(key: key);

  @override
  State<WomensV> createState() => _WomensVState();
}

class _WomensVState extends State<WomensV> {
  List<String>? womensSymptoms = [];

  @override
  void initState() {
    super.initState();
    // Fetch existing womens symptoms for the patient from Firestore
    fetchWomensSymptoms();
  }

  void fetchWomensSymptoms() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('Patients').doc(widget.patientId).get();
      // Get the womens symptoms array
      List<dynamic>? symptoms = patientDoc['Womens'];
      if (symptoms != null) {
        setState(() {
          womensSymptoms = symptoms.cast<String>();
        });
      }
    } catch (e) {
      print('Error fetching womens symptoms: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            height: 100.0,
            color: Colors.blue[900],
            child: Center(
              child: Text(
                'For Women',
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView(
              children: [
                buildSymptomRadioButton('Pregnant?'),
                buildSymptomRadioButton('Post menopause'),
                buildSymptomRadioButton('Hysterectomy'),
                buildSymptomRadioButton('Nil'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSymptomRadioButton(String symptom) {
    bool isSelected = womensSymptoms != null && womensSymptoms!.contains(symptom);

    return ListTile(
      leading: Radio(
        value: symptom,
        groupValue: isSelected ? symptom : null,
        onChanged: (_) {},
      ),
      title: Text(symptom),
    );
  }
}
