import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class OthersV extends StatefulWidget {
  final String patientId;
  const OthersV({Key? key, required this.patientId}) : super(key: key);

  @override
  State<OthersV> createState() => _OthersVState();
}

class _OthersVState extends State<OthersV> {
  List<String>? otherSymptoms = [];

  @override
  void initState() {
    super.initState();
    // Fetch existing symptoms for the patient from Firestore
    fetchOtherSymptoms();
  }

  void fetchOtherSymptoms() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('Patients').doc(widget.patientId).get();
      // Get the symptoms array
      List<dynamic>? symptoms = patientDoc['Others'];
      if (symptoms != null) {
        setState(() {
          otherSymptoms = symptoms.cast<String>();
        });
      }
    } catch (e) {
      print('Error fetching other symptoms: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            height: 100.0,
            color: Colors.blue[900],
            child: Center(
              child: Text(
                'Others',
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView(
              children: [
                buildSymptomRadioButton('History of regular alcohol use or within 24  hours'),
                buildSymptomRadioButton('Use of Steroids / cortisone inthe past year'),
                buildSymptomRadioButton('History of “Stret drugs” use or within 30 days '),
                buildSymptomRadioButton('Nil'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSymptomRadioButton(String symptom) {
    bool isSelected = otherSymptoms != null && otherSymptoms!.contains(symptom);

    return ListTile(
      leading: Radio(
        value: symptom,
        groupValue: isSelected ? symptom : null,
        onChanged: (_) {},
      ),
      title: Text(symptom),
    );
  }
}
