import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class CancerV extends StatefulWidget {
  final String patientId;
  const CancerV({Key? key, required this.patientId}) : super(key: key);

  @override
  State<CancerV> createState() => _CancerVState();
}

class _CancerVState extends State<CancerV> {
  List<String>? cardiovascularSymptoms = [];

  @override
  void initState() {
    super.initState();
    // Fetch existing cardiovascular symptoms for the patient from Firestore
    fetchCardiovascularSymptoms();
  }

  void fetchCardiovascularSymptoms() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('Patients').doc(widget.patientId).get();
      // Get the cardiovascular symptoms array
      List<dynamic>? symptoms = patientDoc['Cancer'];
      if (symptoms != null) {
        setState(() {
          cardiovascularSymptoms = symptoms.cast<String>();
        });
      }
    } catch (e) {
      print('Error fetching cardiovascular symptoms: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            height: 100.0,
            color: Colors.blue[900],
            child: Center(
              child: Text(
                'Cancer/Chemotherapy/Radiation',
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),

          Column(
            children: [
              buildSymptomRadioButton('Cancer'),
              buildSymptomRadioButton('Chemotherapy'),
              buildSymptomRadioButton('Radiation'),
              buildSymptomRadioButton('Nil'),

            ],
          )
        ],
      ),
    );
  }
  Widget buildSymptomRadioButton(String symptom) {
    bool isSelected = cardiovascularSymptoms != null && cardiovascularSymptoms!.contains(symptom);

    return Row(
      children: <Widget>[
        Radio(
          value: symptom,
          groupValue: isSelected ? symptom : null,
          onChanged: (_) {},
        ),
        Text(symptom),
      ],
    );
  }

}

