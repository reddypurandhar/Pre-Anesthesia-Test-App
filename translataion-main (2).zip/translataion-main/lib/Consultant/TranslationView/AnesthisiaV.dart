import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AnesthesiaV extends StatefulWidget {
  final String patientId;
  const AnesthesiaV({Key? key, required this.patientId}) : super(key: key);

  @override
  State<AnesthesiaV> createState() => _AnesthesiaVState();
}

class _AnesthesiaVState extends State<AnesthesiaV> {
  List<String>? anesthesiaSymptoms = [];

  @override
  void initState() {
    super.initState();
    // Fetch existing anesthesia symptoms for the patient from Firestore
    fetchAnesthesiaSymptoms();
  }

  void fetchAnesthesiaSymptoms() async {
    try {
      DocumentSnapshot patientDoc =
      await FirebaseFirestore.instance.collection('Patients').doc(widget.patientId).get();
      // Get the anesthesia symptoms array
      List<dynamic>? symptoms = patientDoc['Anesthesia'];
      if (symptoms != null) {
        setState(() {
          anesthesiaSymptoms = symptoms.cast<String>();
        });
      }
    } catch (e) {
      print('Error fetching anesthesia symptoms: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            height: 100.0,
            color: Colors.blue[900],
            child: Center(
              child: Text(
                'Previous Anesthesia',
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView(
              children: [
                buildSymptomRadioButton('Anesthesia within one year'),
                buildSymptomRadioButton('History of difficult intubation  '),
                buildSymptomRadioButton('Any objection to spinal / epidural anesthesia'),
                buildSymptomRadioButton('Adverse reaction to anesthesia'),
                buildSymptomRadioButton('Relative with Malignant Hyperthennia'),
                buildSymptomRadioButton('Nausea or vomiting after anesthesia'),
                buildSymptomRadioButton('Are you aware of the risk of eating or \n drinking the day of your anesthesia'),
                buildSymptomRadioButton('Nil'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSymptomRadioButton(String symptom) {
    bool isSelected = anesthesiaSymptoms != null && anesthesiaSymptoms!.contains(symptom);

    return ListTile(
      leading: Radio(
        value: symptom,
        groupValue: isSelected ? symptom : null,
        onChanged: (_) {},
      ),
      title: Text(symptom),
    );
  }
}
