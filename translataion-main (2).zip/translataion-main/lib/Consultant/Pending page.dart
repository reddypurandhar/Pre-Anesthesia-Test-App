import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PendingPage extends StatefulWidget {
  final String id;
  const PendingPage({Key? key, required this.id}) : super(key: key);

  @override
  State<PendingPage> createState() => _PendingPageState();
}

class _PendingPageState extends State<PendingPage> {
  late List<DocumentSnapshot> patients = [];
  List<String> selectedPatients = [];

  @override
  void initState() {
    super.initState();
    _fetchPatients();
  }

  Future<void> _fetchPatients() async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection(
        'Patients')
        .where('status', isEqualTo: 'pending')
        .where('Assigned Doctor ID',isEqualTo:widget.id)
        .get();
    setState(() {
      patients = querySnapshot.docs;
    });
  }


  void _togglePatientSelection(String patientId) {
    setState(() {
      if (selectedPatients.contains(patientId)) {
        selectedPatients.remove(patientId);
      } else {
        selectedPatients.add(patientId);
      }
    });
  }

  void _assignDoctorToPatients() async {
    try {
      for (String patientId in selectedPatients) {
        await FirebaseFirestore.instance.collection('Patients')
            .doc(patientId)
            .update({
          'Assigned Doctor ID': 'ddd',
        });
      }
      // Show success message or navigate back
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Assigned doctor to selected patients successfully'),
      ));

    } catch (e) {
      print('Error assigning doctor to patients: $e');
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Error assigning doctor to patients'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        title: const Text('Pending Patients'),
      ),
      body: patients.isEmpty
          ? Center(
        child: const Text(
          'No approved patients',
          style: TextStyle(fontSize: 16),
        ),
      )
          : ListView.builder(
        itemCount: patients.length,
        itemBuilder: (context, index) {
          DocumentSnapshot patient = patients[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: patient['photoUrl'] != null
                  ? NetworkImage(patient['photoUrl'])
                  : null,
              child: patient['photoUrl'] == null
                  ? Icon(Icons.person)
                  : null,
            ),
            title: Text(patient['name']),
            subtitle: Text('Patient ID: ${patient.id}'),
            onTap: () {
              _togglePatientSelection(patient.id);
            },

          );
        },
      ),
    );
  }}

