// import 'package:flutter/material.dart';
//
// class ConsultantPatientDetails extends StatefulWidget {
//   final int patientId;
//
//   ConsultantPatientDetails({required this.patientId});
//
//   @override
//   _ConsultantPatientDetailsState createState() =>
//       _ConsultantPatientDetailsState();
// }
//
// class _ConsultantPatientDetailsState extends State<ConsultantPatientDetails> {
//   TextEditingController _usernameController = TextEditingController();
//   TextEditingController _ageController = TextEditingController();
//   TextEditingController _heightController = TextEditingController();
//   TextEditingController _weightController = TextEditingController();
//   TextEditingController _procedureController = TextEditingController();
//   TextEditingController _dateofsurgeryController = TextEditingController();
//
//   @override
//   void initState() {
//     super.initState();
//     // Here, you can use the patientId received in the widget and fetch patient details
//     // from your database or any other source
//     print('Patient ID: ${widget.patientId}');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blue[900],
//       appBar: AppBar(
//         backgroundColor: Colors.blue[900],
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           color: Colors.white,
//           onPressed: () {
//             Navigator.of(context).pop();
//           },
//         ),
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(20.0),
//               child: Text(
//                 'Patient Details',
//                 style: TextStyle(
//                   fontSize: 20,
//                   fontWeight: FontWeight.w500,
//                   color: Colors.white,
//                 ),
//               ),
//             ),
//             SizedBox(height: 20),
//             Container(
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(40),
//                   topRight: Radius.circular(40),
//                 ),
//               ),
//               padding: EdgeInsets.all(20.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   _buildTextField('Name', _usernameController),
//                   _buildTextField('Age', _ageController),
//                   _buildTextField('Height', _heightController),
//                   _buildTextField('Weight', _weightController),
//                   _buildTextField('Procedure', _procedureController),
//                   _buildTextField(
//                       'Date of Surgery', _dateofsurgeryController),
//                   SizedBox(height: 30),
//                   ElevatedButton(
//                     onPressed: () {},
//                     style: ElevatedButton.styleFrom(
//                       primary: Colors.blue[900],
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       padding:
//                       EdgeInsets.symmetric(vertical: 15, horizontal: 50),
//                     ),
//                     child: Text(
//                       'Previous History of Patient',
//                       style: TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.w300,
//                         color: Colors.white,
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 30),
//                   ElevatedButton(
//                     onPressed: () {},
//                     style: ElevatedButton.styleFrom(
//                       primary: Colors.blue[900],
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       padding:
//                       EdgeInsets.symmetric(vertical: 15, horizontal: 100),
//                     ),
//                     child: Text(
//                       'Lab Reports',
//                       style: TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.w300,
//                         color: Colors.white,
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 30),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       ElevatedButton(
//                         onPressed: () {
//
//                         },
//                         style: ElevatedButton.styleFrom(
//                           primary: Colors.blue[900],
//                           padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//                           minimumSize: Size(150, 0),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(0),
//                           ),
//                         ),
//                         child: Text(
//                           'Approve',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.w300,
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 10),
//                       ElevatedButton(
//                         onPressed: () {},
//                         style: ElevatedButton.styleFrom(
//                           primary: Colors.blue[900],
//                           padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//                           minimumSize: Size(150, 0),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(0),
//                           ),
//                         ),
//                         child: Text(
//                           'Reject',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.w300,
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 30),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildTextField(String label, TextEditingController controller) {
//     return Container(
//       padding: EdgeInsets.symmetric(vertical: 8.0),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: [
//           SizedBox(
//             width: 120,
//             child: Text(
//               label,
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.w300,
//                 color: Colors.black,
//               ),
//             ),
//           ),
//           Text(
//             ":",
//             style: TextStyle(
//               fontSize: 20,
//               fontWeight: FontWeight.w500,
//               color: Colors.black,
//             ),
//           ),
//           SizedBox(width: 8),
//           Expanded(
//             child: TextField(
//               controller: controller,
//               style: TextStyle(color: Colors.black),
//               decoration: InputDecoration(
//                 enabledBorder: UnderlineInputBorder(
//                   borderSide: BorderSide(color: Colors.black),
//                 ),
//                 focusedBorder: UnderlineInputBorder(
//                   borderSide: BorderSide(color: Colors.black, width: 2.0),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
