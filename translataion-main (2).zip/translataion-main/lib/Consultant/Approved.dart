import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class ApprovedPage extends StatefulWidget {
  const ApprovedPage({Key? key}) : super(key: key);

  @override
  State<ApprovedPage> createState() => _ApprovedPageState();
}

class _ApprovedPageState extends State<ApprovedPage> {
  late List<DocumentSnapshot> patients = [];
  List<String> selectedPatients = [];

  @override
  void initState() {
    super.initState();
    _fetchPatients();
  }

  Future<void> _fetchPatients() async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection(
        'Patients')
          .where('status', isEqualTo: 'Approved')

        .get();
    setState(() {
      patients = querySnapshot.docs;
    });
  }


  void _togglePatientSelection(String patientId) {
    setState(() {
      if (selectedPatients.contains(patientId)) {
        selectedPatients.remove(patientId);
      } else {
        selectedPatients.add(patientId);
      }
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(  backgroundColor: Colors.blue[900],
        title: const Text('Approved Patients'),
      ),
      body: patients.isEmpty
          ? Center(
        child: const Text(
          'No approved patients',
          style: TextStyle(fontSize: 16),
        ),
      )
          : ListView.builder(
        itemCount: patients.length,
        itemBuilder: (context, index) {
          DocumentSnapshot patient = patients[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: patient['photoUrl'] != null
                  ? NetworkImage(patient['photoUrl'])
                  : null,
              child: patient['photoUrl'] == null
                  ? Icon(Icons.person)
                  : null,
            ),
            title: Text(patient['name']),
            subtitle: Text('Patient ID: ${patient.id}'),
            onTap: () {
              _togglePatientSelection(patient.id);
            },

          );
        },
      ),
    );
  }}
