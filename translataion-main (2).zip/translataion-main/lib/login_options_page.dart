import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:mohit/HomePage.dart';
import 'Consultant/Consultant_login.dart';
import 'Doctor/DoctorLogin.dart';
import 'Patient/PatientLogin.dart';
import 'Tech/tech_login.dart';

class LoginOptions extends StatefulWidget {
  @override
  State<LoginOptions> createState() => _LoginOptionsState();
}

class _LoginOptionsState extends State<LoginOptions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.blue[900],
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ClipPath(
                  clipper: WaveClipperOne(),
                  child: Container(
                    height: 150,
                    color: Colors.white,
                    child: Center(
                      child: Text(
                        "Welcome",
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 45),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DoctorCard(),
                    SizedBox(width: 20),
                    ConsultantCard(),
                  ],
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TechCard(),
                    SizedBox(width: 20),
                    PatientCard(),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class DoctorCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DoctorLogin()),
        );
      },
      child: Card(
        elevation: 4,
        child: SizedBox(
          width: 150,
          height: 200,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/doctor.png', width: 100, height: 100),
              SizedBox(height: 10),
              Text(
                'Doctor',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ConsultantCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => consultant()),
        );
      },
      child: Card(
        elevation: 4,
        child: SizedBox(
          width: 150,
          height: 200,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/consultant.png', width: 100, height: 100),
              SizedBox(height: 10),
              Text(
                'Consultant',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TechCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => TechLogin()),
        );
      },
      child: Card(
        elevation: 4,
        child: SizedBox(
          width: 150,
          height: 200,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/tech.png', width: 100, height: 100),
              SizedBox(height: 10),
              Text(
                'Tech',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PatientCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => PatientLogin()),
        );
      },
      child: Card(
        elevation: 4,
        child: SizedBox(
          width: 150,
          height: 200,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/patient.png', width: 100, height: 100),
              SizedBox(height: 10),
              Text(
                'Patient',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
