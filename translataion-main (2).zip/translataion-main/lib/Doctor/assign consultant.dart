import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mohit/Doctor/HomeScreen.dart';

class AssignConsultant extends StatefulWidget {
  const AssignConsultant({Key? key}) : super(key: key);

  @override
  State<AssignConsultant> createState() => _AssignConsultantState();
}

class _AssignConsultantState extends State<AssignConsultant> {
  late TextEditingController _searchController;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildDoctorCard(BuildContext context, DocumentSnapshot doctor) {
    return Card(
      elevation: 3,
      child: ListTile(
        title: Text(
          doctor['name'],
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('Doctor Id: ' + doctor['doctor_id']),
        onTap: () {
          _showAssignPatientDialog(context, doctor);
        },
      ),
    );
  }

  Widget _buildDoctorList(BuildContext context,
      List<DocumentSnapshot> doctors) {
    return ListView.builder(
      itemCount: doctors.length,
      itemBuilder: (context, index) {
        return _buildDoctorCard(context, doctors[index]);
      },
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          labelText: 'Search by Doctor ID',
          border: OutlineInputBorder(),
        ),
        onChanged: (value) {
          // Perform search based on doctor ID
          // For example, you can filter the list of doctors based on the entered ID
        },
      ),
    );
  }

  Future<void> _showAssignPatientDialog(BuildContext context,
      DocumentSnapshot doctor) async {
    String doctorId = doctor['doctor_id'];
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(

          title: Text('Assign Dr ${doctor['name']} to patients?'),
          content: SingleChildScrollView(
            child: Column(
              children: [


              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AssignToPatients(doctorId: doctorId) ),
                );
              },
              child: Text('Yes'),
            ),
          ],
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assign Consultant'),
      ),
      body: Column(
        children: [
          _buildSearchBar(context),
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection('Consultant').snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}'),
                  );
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }

                List<DocumentSnapshot> doctors = snapshot.data!.docs;

                return _buildDoctorList(context, doctors);
              },
            ),
          ),
        ],
      ),
    );
  }
}




class AssignToPatients extends StatefulWidget {
  final String doctorId;

  const AssignToPatients({Key? key, required this.doctorId}) : super(key: key);

  @override
  _AssignToPatientsState createState() => _AssignToPatientsState();
}

class _AssignToPatientsState extends State<AssignToPatients> {
  late List<DocumentSnapshot> patients = [];
  List<String> selectedPatients = [];

  @override
  void initState() {
    super.initState();
    _fetchPatients();
  }

  Future<void> _fetchPatients() async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('Patients')
        .where('status', isEqualTo: 'pending')
        .where('Assigned Doctor ID', isEqualTo: "false")
        .get();
    setState(() {
      patients = querySnapshot.docs;
    });
  }


  void _togglePatientSelection(String patientId) {
    setState(() {
      if (selectedPatients.contains(patientId)) {
        selectedPatients.remove(patientId);
      } else {
        selectedPatients.add(patientId);
      }
    });
  }

  void _assignDoctorToPatients() async {
    try {
      for (String patientId in selectedPatients) {
        await FirebaseFirestore.instance.collection('Patients').doc(patientId).update({
          'Assigned Doctor ID': widget.doctorId,
        });
      }
      // Show success message or navigate back
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Assigned doctor to selected patients successfully'),
      ));
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const DcotorHomeScreen()),
      );
    } catch (e) {
      print('Error assigning doctor to patients: $e');
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Error assigning doctor to patients'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assign to Patients'),
      ),
      body: patients.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: patients.length,
        itemBuilder: (context, index) {
          DocumentSnapshot patient = patients[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: patient['photoUrl'] != null
                  ? NetworkImage(patient['photoUrl'])
                  : null,
              child: patient['photoUrl'] == null ? Icon(Icons.person) : null,
            ),
            title: Text(patient['name']),
            subtitle: Text('Patient ID: ${patient.id}'),
            onTap: () {
              _togglePatientSelection(patient.id);
            },
            trailing: Icon(
              selectedPatients.contains(patient.id) ? Icons.check_circle : Icons.radio_button_unchecked,
              color: selectedPatients.contains(patient.id) ? Colors.blue : null,
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _assignDoctorToPatients,
        child: Icon(Icons.assignment),
      ),
    );
  }
}