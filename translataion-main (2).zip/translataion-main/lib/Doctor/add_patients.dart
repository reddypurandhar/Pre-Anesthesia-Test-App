import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mohit/Doctor/HomeScreen.dart';

class Add_Patient extends StatefulWidget {
  @override
  _Add_PatientState createState() => _Add_PatientState();
}

class _Add_PatientState extends State<Add_Patient> {
  File? _image;
  final picker = ImagePicker();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController heightController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController procedureController = TextEditingController();
  final TextEditingController dateOfSurgeryController = TextEditingController();
  final TextEditingController patientidcontroller = TextEditingController();
  final TextEditingController passwordcontroller = TextEditingController();

  Future getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  Future<void> uploadImageToStorage(String patientId) async {
    if (_image == null) return;

    Reference ref = FirebaseStorage.instance.ref().child('patient_images').child('$patientId.jpg');

    await ref.putFile(_image!);

    String imageUrl = await ref.getDownloadURL();

    // Once image is uploaded, add patient data along with image URL to Firestore
    addPatientToFirestore(patientId, imageUrl);
  }

  Future<void> addPatientToFirestore(String patientId, String imageUrl) async {
    await FirebaseFirestore.instance.collection('Patients').doc(patientId).set({
      'name': nameController.text,
      'age': ageController.text,
      'gender': genderController.text,
      'height': heightController.text,
      'weight': weightController.text,
      'phone': phoneController.text,
      'password':passwordcontroller.text,
      'procedure': procedureController.text,
      'dateOfSurgery': dateOfSurgeryController.text,
      'photoUrl': imageUrl,
      'status':'pending',
      'Assigned Doctor ID':"false",
      'rejectionReason':"false"
    });

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>DcotorHomeScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      appBar: AppBar(
        backgroundColor: Colors.blue[900],

        title: Text(
          'Add Patient',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            mainAxisSize: MainAxisSize.max,
            children: [
              SizedBox(height: 25),
              GestureDetector(
                onTap: getImage,
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.grey.withOpacity(0.2),
                  ),
                  child: _image != null
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.file(_image!, fit: BoxFit.cover),
                  )
                      : Icon(
                    Icons.add_a_photo,
                    size: 50,
                  ),
                ),
              ),
              SizedBox(height: 25),
              Container(
                width: double.infinity,
                alignment: AlignmentDirectional(0, 1),
                child: Container(
                  width: 100,
                  constraints: BoxConstraints(
                    minWidth: double.infinity,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 25),
                        TextFormField(
                          controller: patientidcontroller,
                          decoration: InputDecoration(
                            labelText: 'Patient Id',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: nameController,
                          decoration: InputDecoration(
                            labelText: 'Name',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: ageController,
                          decoration: InputDecoration(
                            labelText: 'Age',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: genderController,
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: heightController,
                          decoration: InputDecoration(
                            labelText: 'Height',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: weightController,
                          decoration: InputDecoration(
                            labelText: 'Weight',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: passwordcontroller,
                          decoration: InputDecoration(
                            labelText: 'Create Password',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: phoneController,
                          decoration: InputDecoration(
                            labelText: 'Phone',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: procedureController,
                          decoration: InputDecoration(
                            labelText: 'Procedure',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        TextFormField(
                          controller: dateOfSurgeryController,
                          decoration: InputDecoration(
                            labelText: 'Date of Surgery',
                            hintText: 'DD-MM-YYYY',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            filled: true,
                            fillColor: Colors.grey[200],
                            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          ),
                        ),
                        SizedBox(height: 25),
                        ElevatedButton(
                          onPressed: () {
                            String patientId = patientidcontroller.text;
                            uploadImageToStorage(patientId);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              'Add',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 25),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}