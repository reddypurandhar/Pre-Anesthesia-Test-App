import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mohit/login_options_page.dart';

import '../Tech/patient_details view.dart';
import 'Patient List.dart';
import 'Patient details.dart';
import 'Previous_history.dart';
import 'add_patients.dart';
import 'assign consultant.dart';
import 'createnewlogin.dart';
import 'doctor_profile.dart';

class DcotorHomeScreen extends StatefulWidget {
  const DcotorHomeScreen({Key? key}) : super(key: key);

  @override
  State<DcotorHomeScreen> createState() => _DcotorHomeScreenState();
}

class _DcotorHomeScreenState extends State<DcotorHomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        title: Text('Hello Doctor  '), // Replace with the doctor's name
        actions: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Doctor_Profile()),
              );
            },
            child: CircleAvatar(
              // Profile picture avatar
              child: Icon(Icons.person),
            ),
          ),
        ],

      ),
      drawer: Drawer(

        child: ListView(
          children: [
            DrawerHeader(
        decoration: BoxDecoration(
        color: Colors.blue[900],)
,                child:Column()
            )
,
            ListTile(

              title: Text('Create New Login'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CreateNewLogin()),
                );
              },
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginOptions()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 50,),
          Container(
            width: 250,
            height: 60,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Add_Patient()),
                );
              },
              child: Text('Add Patient'),
            ),
          ),
          SizedBox(height: 20),
          Container(height: 60,
            width: 250,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AssignConsultant()),
                );
              },
              child: Text('Add Consultant'),
            ),
          ),
          SizedBox(height: 20),
          Container(height: 60,
            width: 250,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black
              ),
              onPressed: () {
                // Navigate to Patient List page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientList()),
                );
              },
              child: Text('Patient List'),
            ),
          ),
          SizedBox(height: 40),
          Text(
            'Today\'s',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('Patients').snapshots(),
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator(); // Placeholder for loading indicator
                }

                return ListView.builder(
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (BuildContext context, int index) {
                    var patient = snapshot.data!.docs[index];
                    return Card(
                      elevation: 4,
                      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        onTap: () {
                          // Navigate to Patient_Details and pass the patient ID
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PatientDetailsWithPrevious(patientId: patient.id,
                                name: patient['name'],
                                age: patient['age'],
                                gender: patient['gender'],
                                height: patient['height'],
                                phoneno: patient['phone'],
                                procedure: patient['procedure'],
                                dos: patient['dateOfSurgery'], weight: patient['weight'], photurl: patient['photoUrl'],),
                            ),
                          );
                        },
                        leading: CircleAvatar(
                          // Profile picture avatar
                          backgroundImage:NetworkImage(patient['photoUrl'])  // Replace 'assets/default_avatar.jpg' with your default avatar image path
                        ),
                        title: Text(patient['name']),
                        subtitle: Text('Age: ${patient['age']}, ID: ${patient.id}'),
                        trailing: Text('Status: ${patient['status']}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),

        ],
      ),
    );
  }
}