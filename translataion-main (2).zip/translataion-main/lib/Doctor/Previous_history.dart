import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:mohit/Doctor/Translations/gastro.dart';
import 'package:mohit/HomePage.dart';

import 'Translations/Bladder.dart';
import 'Translations/Cardiovascular.dart';
import 'Translations/Diabetes.dart';
import 'Translations/Neurological.dart';
import 'Translations/anesthesia.dart';
import 'Translations/blood.dart';
import 'Translations/cancer.dart';
import 'Translations/eye-ear.dart';
import 'Translations/forwomen.dart';
import 'Translations/others.dart';
import 'Translations/respiratory.dart';

class PreviousHistory extends StatefulWidget {
  final String Patientid;
  final String name;
  final String photourl;
  const PreviousHistory({Key? key, required this.Patientid, required this.name, required this.photourl, }) : super(key: key);

  @override
  State<PreviousHistory> createState() => _PreviousHistoryState();
}

class _PreviousHistoryState extends State<PreviousHistory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('History of Patients',style: TextStyle(color: Colors.black),),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.blue[900],
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  ClipPath(
                    clipper: WaveClipperOne(),
                    child: Container(
                      height: 180,
                      color: Colors.white,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 50,
                              backgroundImage: NetworkImage(widget.photourl), // Replace with your profile image
                            ),
                            SizedBox(height: 10),
                            Text(
                              widget.name,
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 45),
                  Container(
                    width: 250,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Cardiovascular(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Cardiovascular Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Respiratory Disease
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  respiratory(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Respiratory Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Neurological Disorder
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Neurological(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Neurological Disorder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Diabetes
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Diabetes(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Diabetes',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Kidney/Bladder
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Bladder(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Kidney/Bladder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Gastro-Interstinal Disease
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  gastro(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Gastro-Interstinal Disease',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Blood Disorder
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) =>  Blood(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Blood Disorder',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Eye/Ear
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  eye(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Eye/Ear',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Cancer/Chemotherapy/Radiation
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Cancer(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Cancer/Chemotherapy/Radiation',style: TextStyle(fontSize: 16),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for For Women
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Womens(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('For Women',style: TextStyle(fontSize: 19),),
                    ),
                  ), SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Previous Anesthesia
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Anesthesia(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Previous Anesthesia',style: TextStyle(fontSize: 19),),
                    ),
                  ),
                  SizedBox(height: 20,),
                  Container(
                    width: 250,height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        // Navigate to the respective screen for Other
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>  Others(patientId:widget.Patientid,)),
                        );
                      },
                      child: Text('Other',style: TextStyle(fontSize: 19),),
                    ),
                  ),
                  SizedBox(height: 50),
                  Container(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: EdgeInsets.symmetric(vertical: 20),
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Save'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
