import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'createnewlogin.dart';

class AddConsultant extends StatefulWidget {
  const AddConsultant({Key? key}) : super(key: key);

  @override
  State<AddConsultant> createState() => _AddConsultantState();
}

class _AddConsultantState extends State<AddConsultant> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _techIdController = TextEditingController();
  final TextEditingController _mobileNumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue[900],
        title: Text('Add Consulatant'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView(
                children: [
                  _buildFormItem('Name', _nameController),
                  _buildFormItem('Age', _ageController),
                  _buildFormItem('Gender', _genderController),
                  _buildFormItem('Doctor ID', _techIdController),
                  _buildFormItem('Mobile Number', _mobileNumberController),
                  _buildFormItem('Password', _passwordController),
                ],
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: Container(
                width: double.infinity,
                height: 39,
                child: ElevatedButton(
                  onPressed: () {
                    _updateTechData();
                  },
                  child: Text('Save'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormItem(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            flex: 3,
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                border: UnderlineInputBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _updateTechData() async {
    try {
      // Check if document with the same Tech ID exists
      DocumentSnapshot docSnapshot = await _firestore.collection('Consultant').doc(_techIdController.text).get();
      if (docSnapshot.exists) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Tech ID already exists!'),
          backgroundColor: Colors.red,
        ));
        return; // Exit function if document exists
      }

      // If document doesn't exist, add the data
      await _firestore.collection('Consultant').doc(_techIdController.text).set({
        'name': _nameController.text,
        'age': _ageController.text,
        'gender': _genderController.text,
        'mobile_number': _mobileNumberController.text,
        'password': _passwordController.text,
        'doctor_id':_techIdController.text,
      });
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => CreateNewLogin()),
      );
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Tech data added successfully!'),
      ));
    } catch (e) {
      print('Error adding tech data: $e');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Failed to add tech data'),
        backgroundColor: Colors.red,
      ));
    }
  }

}
