import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:translator/translator.dart';
import 'package:flutter/services.dart';

class Others extends StatefulWidget {
  final String patientId;
  const Others({Key? key, required this.patientId,  }) : super(key: key);
  @override
  _OthersState createState() => _OthersState();
}

class _OthersState extends State<Others> {
  final MethodChannel _channel = const MethodChannel('samples.flutter.dev/tts');
  stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _text = 'Press the button and start speaking';
  String _translatedText = ''; // Variable to store translated text
  String _selectedSpeechLanguage = 'en-IN'; // Default to Tamil language
  String _selectedTranslateLanguage =
      'ta'; // Default to Tamil language for translation
  final translator = GoogleTranslator();

  String? selectedSymptom;
  List<String> selectedSymptoms = [];

  void handleSymptomSelection(String symptom) {
    setState(() {
      if (selectedSymptoms.contains(symptom)) {
        selectedSymptoms.remove(symptom);
      } else {
        selectedSymptoms.add(symptom);
      }
    });
  }

  void submitSymptoms() async {
    if (selectedSymptoms.isNotEmpty) {
      try {
        await FirebaseFirestore.instance.collection('Patients').doc(widget.patientId).update({
          'Others': selectedSymptoms,
        });

        print('Symptoms submitted successfully');
        Navigator.pop(context);
      } catch (e) {
        print('Error submitting symptoms: $e');
      }
    }
  }


  void _startListening() async {
    if (!_isListening) {
      bool available = await _speech.initialize(
        onStatus: (status) => print('Status: $status'),
        onError: (error) => print('Error: $error'),
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (result) async {
            setState(() {
              _text = result.recognizedWords;
            });
            // Translate recognized text to selected language
            String translatedText = await translateText(
              result.recognizedWords,
              _selectedTranslateLanguage,
              _selectedSpeechLanguage,
            );
            setState(() {
              _translatedText = translatedText;
            });
            // Print the translated text
            print("Translated text: $_translatedText");
          },
          localeId: _selectedSpeechLanguage,
        );
      }
    }
  }

  void _stopListening() {
    _speech.stop();
    setState(() => _isListening = false);
  }

  Future<String> translateText(
      String text, String toLanguage, String fromLanguage) async {
    try {
      Translation translatedText = await translator.translate(
        text,
        from: fromLanguage.substring(
            0, 2), // Get the first two characters for Google Translate code
        to: toLanguage,
      );
      return translatedText.text;
    } catch (e) {
      print("Translation error: $e");
      return "Translation not available";
    }
  }

  Future<void> speak(String text, String language) async {
    try {
      await _channel
          .invokeMethod('speak', {'text': text, 'language': language});
    } on PlatformException catch (e) {
      print("Failed to invoke method: '${e.message}'.");
    }
  }

  void swapDropdownValues() {
    setState(() {
      print("hi");
      String temp = _selectedSpeechLanguage;
      _selectedSpeechLanguage = _selectedTranslateLanguage + "-IN";
      _selectedTranslateLanguage = temp[0] + temp[1];

      //Toggle arrow direction
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.blue[900],
      ),
      body: Column(
        children: <Widget>[
          Container(
            height: 150.0,
            width: double.infinity,
            color: Colors.blue[900],
            padding: EdgeInsets.symmetric(horizontal: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'From: $_selectedSpeechLanguage',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                        ),
                      ),
                      SizedBox(height: 10.0),
                      Text(
                        _text,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'To: $_selectedTranslateLanguage',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                        ),
                        textAlign: TextAlign.right,
                      ),
                      SizedBox(height: 10.0),
                      Text(
                        _translatedText,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0,
                        ),
                        textAlign: TextAlign.right,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 20.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Text('From'),
                            DropdownButton<String>(
                              value: _selectedSpeechLanguage,
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _selectedSpeechLanguage = newValue;
                                  });
                                }
                              },
                              items: <String>[
                                'as-IN',
                                'bn-IN',
                                'gu-IN',
                                'hi-IN',
                                'kn-IN',
                                'ml-IN',
                                'mr-IN',
                                'or-IN',
                                'pa-IN',
                                'ta-IN',
                                'te-IN',
                                'ur-IN',
                                'en-IN',
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.compare_arrows),
                        onPressed: () {
                          swapDropdownValues();
                        },
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Text('To'),
                            DropdownButton<String>(
                              value: _selectedTranslateLanguage,
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _selectedTranslateLanguage = newValue;
                                  });
                                }
                              },
                              items: <String>[
                                'as', // Assamese
                                'bn', // Bengali
                                'gu', // Gujarati
                                'hi', // Hindi
                                'kn', // Kannada
                                'ml', // Malayalam
                                'mr', // Marathi
                                'or', // Odia
                                'pa', // Punjabi
                                'ta', // Tamil
                                'te', // Telugu
                                'ur', // Urdu
                                'en',
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      FloatingActionButton(
                        onPressed:
                        _isListening ? _stopListening : _startListening,
                        child: Icon(_isListening ? Icons.stop : Icons.mic),
                      ),
                      SizedBox(width: 20.0),
                      FloatingActionButton(
                        onPressed: () => speak(_translatedText,
                            _selectedTranslateLanguage + '-IN'),
                        child: Icon(Icons.volume_up),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              height: 100.0,
                              color: Colors.blue[900],
                              child: Center(
                                child: Text(
                                  'Others',
                                  style: TextStyle(
                                    fontSize: 20.0,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 20.0),
                            Text(
                              'Symptoms:',
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 10.0),

                            buildSymptomRadioButton('History of regular alcohol use or within 24  hours'),
                            buildSymptomRadioButton('Use of Steroids / cortisone inthe past year'),
                            buildSymptomRadioButton('History of “Stret drugs” use or within 30 days '),
                            buildSymptomRadioButton('Nil'),



                            ElevatedButton(
                              onPressed:
                              submitSymptoms
                              ,
                              child: Container(
                                width: 250,
                                child: Center(
                                  child: Text('Submit', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  Widget buildSymptomRadioButton(String symptom) {
    return Row(
      children: <Widget>[
        Radio(
          value: symptom,
          groupValue: selectedSymptoms.contains(symptom) ? symptom : null,
          onChanged: (_) {
            handleSymptomSelection(symptom);
          },
        ),
        Text(symptom),
      ],
    );
  }

}


