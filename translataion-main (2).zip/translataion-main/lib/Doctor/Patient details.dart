import 'package:flutter/material.dart';

import 'Previous_history.dart';

class PatientDetailsWithPrevious extends StatefulWidget {
  final String patientId;
  final String name;
  final String age;
  final String gender;
  final String height;
  final String weight;
  final String phoneno;
  final String procedure;
  final String dos;
  final String photurl;


  const PatientDetailsWithPrevious({Key? key,
    required this.patientId,
    required this.name,
    required this.age,
    required this.gender,
    required this.height,
    required this.phoneno,
    required this.procedure,
    required this.dos,
    required this.weight,
    required this.photurl}) : super(key: key);

  @override
  State<PatientDetailsWithPrevious> createState() => _PatientDetailsWithPreviousState();
}

class _PatientDetailsWithPreviousState extends State<PatientDetailsWithPrevious> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 70,
        elevation: 0,
        title: Text('Patient Details'),
        backgroundColor: Colors.blue[900],
        iconTheme: IconThemeData(
            color: Colors.white), // Set back arrow color to black
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTextField('Name              ',initialValue: widget.name),
            _buildTextField('Patient ID        ', initialValue: widget.patientId),
            _buildTextField('Age                  ',initialValue: widget.age),
            _buildTextField('Gender             ',initialValue: widget.gender),
            _buildTextField('Height               ',initialValue: widget.height),
            _buildTextField('Weight               ',initialValue: widget.weight),
            _buildTextField('Phone Number ',initialValue: widget.phoneno),
            _buildTextField('Procedure        ',initialValue: widget.procedure),
            _buildTextField('Date of Surgery',initialValue: widget.dos),
            SizedBox(height: 30),
            Center(
              child: Container(
                width: 250,
                height: 40,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[900]
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PreviousHistory(Patientid: widget.patientId, name: widget.name, photourl:widget.photurl,)),
                    );
                  },
                  child: Text('Previous History of Patients',style: TextStyle(fontSize: 19),),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, {String? initialValue}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(width: 10),
          Expanded(
            child: SizedBox(
              width: 50, // Adjust the width as needed
              child: TextFormField(
                initialValue: initialValue,
                readOnly: true,

                decoration: InputDecoration(
                  fillColor: Colors.grey,
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 20, vertical: 15),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}