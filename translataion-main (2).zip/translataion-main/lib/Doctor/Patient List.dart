import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'Patient details.dart';
import 'Previous_history.dart';

class PatientList extends StatefulWidget {
  const PatientList({Key? key}) : super(key: key);

  @override
  State<PatientList> createState() => _PatientListState();
}

class _PatientListState extends State<PatientList> {
  late TextEditingController _searchController;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        title: Text('Patient List'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by ID or Name',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {}); // Trigger rebuild to update the patient list based on the search query
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('Patients').snapshots(),
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                // Filter patient list based on search query
                var filteredPatients = snapshot.data!.docs.where((patient) {
                  String name = patient['name'].toString().toLowerCase();
                  String id = patient.id.toLowerCase();
                  String searchQuery = _searchController.text.toLowerCase();
                  return name.contains(searchQuery) || id.contains(searchQuery);
                }).toList();

                return ListView.builder(
                  itemCount: filteredPatients.length,
                  itemBuilder: (BuildContext context, int index) {
                    var patient = filteredPatients[index];
                    return Card(
                      elevation: 4,
                      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        onTap: () {
                          // Navigate to PreviousHistoryPage and pass the patient ID
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>PatientDetailsWithPrevious(patientId: patient.id,
                                name: patient['name'],
                                age: patient['age'],
                                gender: patient['gender'],
                                height: patient['height'],
                                phoneno: patient['phone'],
                                procedure: patient['procedure'],
                                dos: patient['dateOfSurgery'], weight: patient['weight'], photurl: patient['photoUrl'],)
                              //
                              // PreviousHistory(Patientid: patient.id, name: patient['name'], photourl:patient['photoUrl'] ,),
                            ),
                          );
                        },
                        leading: CircleAvatar(
                          // Profile picture avatar
                          backgroundImage: NetworkImage(patient['photoUrl']),
                        ),
                        title: Text(patient['name']),
                        subtitle: Text('Age: ${patient['age']}, ID: ${patient.id}'),
                        trailing: Text('Status: ${patient['status']}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
