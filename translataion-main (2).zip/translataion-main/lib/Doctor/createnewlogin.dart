import 'package:flutter/material.dart';

import 'add_consultant.dart';
import 'add_tech.dart';

class CreateNewLogin extends StatefulWidget {
  const CreateNewLogin({Key? key}) : super(key: key);

  @override
  State<CreateNewLogin> createState() => _CreateNewLoginState();
}

class _CreateNewLoginState extends State<CreateNewLogin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Create New Logins'),
        backgroundColor: Colors.blue[900],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 250,
              height: 70,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => AddConsultant()),
                  );
                },
                child: Text('Consultant'),
              ),
            ),
            SizedBox(height: 20),
            Container(
              width: 250,
              height: 60,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => AddTech()),
                  );
                },
                child: Text('Tech'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}